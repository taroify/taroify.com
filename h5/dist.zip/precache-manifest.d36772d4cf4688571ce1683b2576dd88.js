self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d3cde8f3a9395767c295",
    "url": "/h5/css/aboutus.4001ce3a.css"
  },
  {
    "revision": "12c9909f49bdd544cd13",
    "url": "/h5/css/agreement.35519d69.css"
  },
  {
    "revision": "b7614196cb07ef495316",
    "url": "/h5/css/app.76cf66dd.css"
  },
  {
    "revision": "ef3737e363f6034ceda1",
    "url": "/h5/css/asset.5e35cc40.css"
  },
  {
    "revision": "a285332dbde477d00b2d",
    "url": "/h5/css/asset~feedback~setting.01758efc.css"
  },
  {
    "revision": "6832bdae8e18f00ec71b",
    "url": "/h5/css/chunk-vendors.78cbba1b.css"
  },
  {
    "revision": "d46f85cd1af297cbe13c",
    "url": "/h5/css/feedback.5ce3a0f4.css"
  },
  {
    "revision": "8d4deaa3764501d6a1e6",
    "url": "/h5/css/invite.b8987c25.css"
  },
  {
    "revision": "e93d01b235d7df1fa76a",
    "url": "/h5/css/message.13e4a97f.css"
  },
  {
    "revision": "209e546e265e0e86d0ef",
    "url": "/h5/css/notice.fa88167f.css"
  },
  {
    "revision": "35d8fd68c764b17c1fa3",
    "url": "/h5/css/notifications.48118b06.css"
  },
  {
    "revision": "0c4b2f83d29af8cca22d",
    "url": "/h5/css/order.a4138536.css"
  },
  {
    "revision": "df99ca78e6a4ea570e2c",
    "url": "/h5/css/partner-application.717616e4.css"
  },
  {
    "revision": "7f8ad869b5fa1c888feb",
    "url": "/h5/css/payment.f4ab9c3a.css"
  },
  {
    "revision": "aa4d01fb18e21a7a5c12",
    "url": "/h5/css/problem.92023fc9.css"
  },
  {
    "revision": "809073a612c1e724e50d",
    "url": "/h5/css/product.5e7b2e0c.css"
  },
  {
    "revision": "137eba0069f393c574c9",
    "url": "/h5/css/recite.a0b3504c.css"
  },
  {
    "revision": "7a8cab5314fde834e0de",
    "url": "/h5/css/setting.4e3a6363.css"
  },
  {
    "revision": "a76c39e43323dc9d8766",
    "url": "/h5/css/user.ed5aad11.css"
  },
  {
    "revision": "5328ca152b0a77ae36d97fa138413306",
    "url": "/h5/img/bottom-logo.5328ca15.png"
  },
  {
    "revision": "9a681e048635b5d1e91f9bf309c71cad",
    "url": "/h5/img/invite-poster.9a681e04.png"
  },
  {
    "revision": "9e04011bc25b7cba3681d432f399e278",
    "url": "/h5/img/logo.9e04011b.png"
  },
  {
    "revision": "7ca8da85d1d434f8c5ca86b6e9886cbd",
    "url": "/h5/img/me-card-invite.7ca8da85.png"
  },
  {
    "revision": "a19d95753b45b422b646f7dc56866c94",
    "url": "/h5/img/me-cell-partner-application.a19d9575.png"
  },
  {
    "revision": "98433ea40fc617d191c3d70c2a4773e7",
    "url": "/h5/img/operation1.98433ea4.png"
  },
  {
    "revision": "cc5b7a3825a31ae327f0fbbb83afeee3",
    "url": "/h5/img/operation2.cc5b7a38.png"
  },
  {
    "revision": "88dcb4b35af4aadc2b1b88812e03c477",
    "url": "/h5/img/order-status.88dcb4b3.png"
  },
  {
    "revision": "a8bdb4121e4dcbc0f8d93021f2d4f356",
    "url": "/h5/img/partner-application.a8bdb412.jpg"
  },
  {
    "revision": "3c0e040ae9aab575f2feaada0d5774de",
    "url": "/h5/img/security.3c0e040a.png"
  },
  {
    "revision": "3b765cd699000506051aa6b269461826",
    "url": "/h5/img/service.3b765cd6.png"
  },
  {
    "revision": "2d4696dc93101a57b631e04ea6b15653",
    "url": "/h5/img/wechat-official-accounts.2d4696dc.jpg"
  },
  {
    "revision": "cf7d73f5400687897cbc74f3b2336c8d",
    "url": "/h5/index.html"
  },
  {
    "revision": "d3cde8f3a9395767c295",
    "url": "/h5/js/aboutus.ef346f07.js"
  },
  {
    "revision": "12c9909f49bdd544cd13",
    "url": "/h5/js/agreement.67f5b8ac.js"
  },
  {
    "revision": "b7614196cb07ef495316",
    "url": "/h5/js/app.a1e53747.js"
  },
  {
    "revision": "ef3737e363f6034ceda1",
    "url": "/h5/js/asset.5a8709b3.js"
  },
  {
    "revision": "a285332dbde477d00b2d",
    "url": "/h5/js/asset~feedback~setting.2acee046.js"
  },
  {
    "revision": "6832bdae8e18f00ec71b",
    "url": "/h5/js/chunk-vendors.a135aecd.js"
  },
  {
    "revision": "d46f85cd1af297cbe13c",
    "url": "/h5/js/feedback.47a99ce6.js"
  },
  {
    "revision": "8d4deaa3764501d6a1e6",
    "url": "/h5/js/invite.a3fe1ec7.js"
  },
  {
    "revision": "e93d01b235d7df1fa76a",
    "url": "/h5/js/message.54601026.js"
  },
  {
    "revision": "209e546e265e0e86d0ef",
    "url": "/h5/js/notice.4d6bf379.js"
  },
  {
    "revision": "35d8fd68c764b17c1fa3",
    "url": "/h5/js/notifications.7f4a07bd.js"
  },
  {
    "revision": "0c4b2f83d29af8cca22d",
    "url": "/h5/js/order.06cf681f.js"
  },
  {
    "revision": "df99ca78e6a4ea570e2c",
    "url": "/h5/js/partner-application.818b360f.js"
  },
  {
    "revision": "7f8ad869b5fa1c888feb",
    "url": "/h5/js/payment.b606bacb.js"
  },
  {
    "revision": "aa4d01fb18e21a7a5c12",
    "url": "/h5/js/problem.2075aa0f.js"
  },
  {
    "revision": "809073a612c1e724e50d",
    "url": "/h5/js/product.1aa9872f.js"
  },
  {
    "revision": "137eba0069f393c574c9",
    "url": "/h5/js/recite.674d3662.js"
  },
  {
    "revision": "7a8cab5314fde834e0de",
    "url": "/h5/js/setting.3b4d65cb.js"
  },
  {
    "revision": "a76c39e43323dc9d8766",
    "url": "/h5/js/user.7c866735.js"
  },
  {
    "revision": "e62ae1f22fc20b657e971ade32182db8",
    "url": "/h5/manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/h5/robots.txt"
  }
]);